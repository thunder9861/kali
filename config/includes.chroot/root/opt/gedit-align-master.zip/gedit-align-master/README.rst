..


===============================================================================
Align
===============================================================================

Align is a gedit plugin that allows you to arrange blocks of text into
columns easily and quickly.

Just select the text to be arranged, go to ``Edit -> Align``, specify the
column separator and presto you have instant columns. No more pressing tabs
and arranging text manually.
