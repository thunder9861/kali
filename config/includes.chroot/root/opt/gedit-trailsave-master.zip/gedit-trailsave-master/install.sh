#!/bin/sh

mkdir -p ~/.local/share/gedit/plugins
cp trailsave.* ~/.local/share/gedit/plugins

echo "Trailsave installed! Now restart Gedit and active the plugin in Edit > Preferences."
