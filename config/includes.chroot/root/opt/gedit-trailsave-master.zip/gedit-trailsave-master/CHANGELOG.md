Version 3.1.2
-------------

Proper handling of multibyte characters.

Version 3.1.1
-------------

Fix bad bug which could result in non-whitespace text being deleted.

Version 3.1.0
-------------

Significant performance improvements on large files.

Version 3.0.0
-------------

Ported original Trailsave plugin to Gedit 3.
