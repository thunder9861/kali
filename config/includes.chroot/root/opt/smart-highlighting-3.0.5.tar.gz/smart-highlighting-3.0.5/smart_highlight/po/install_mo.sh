#!/bin/sh


LOCALE_DEST=/usr/share/locale

sudo cp -rv ../locale/* ${LOCALE_DEST}


