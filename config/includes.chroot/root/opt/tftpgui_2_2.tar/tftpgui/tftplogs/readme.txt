This is the default directory where tftpgui creates logfiles.



You can change this directory to any one you have previously
created, by using the setup button within tftpgui.
