#!/usr/bin/python
# -*- coding: utf-8 -*-

#  Copyright © 2012-2013  B. Clausius <barcc@gmx.de>
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <http://www.gnu.org/licenses/>.


from glob import glob
from distutils.core import setup


setup(
    name='gedit-classbrowser3g',
    version='1.0.2',
    license='GPL-3',
    author='B. Clausius',
    author_email='barcc@gmx.de',
    description='Class Browser for gedit',
    long_description=
'''The class browser is located in the side pane and lists functions,
classes, etc. in a tree view. The default parser uses exuberant ctags
to support a wide range of languages. Special parsers are used for
Python, HTML, XML/Mallard/DocBook, Diff, Ruby and Markdown.''',
    url='https://launchpad.net/gedit-classbrowser3g',

    data_files=[
                ('lib/gedit/plugins/', ['classbrowser3g.plugin']),
                ('lib/gedit/plugins/classbrowser3g/', glob('classbrowser3g/*.py')),
                ('lib/gedit/plugins/classbrowser3g/', glob('classbrowser3g/*.ui')),
                ('lib/gedit/plugins/classbrowser3g/parsers/', glob('classbrowser3g/parsers/*.py')),
                ('lib/gedit/plugins/classbrowser3g/pixmaps/', glob('classbrowser3g/pixmaps/*.png')),
                ('lib/gedit/plugins/classbrowser3g/pixmaps/', glob('classbrowser3g/pixmaps/*.xpm')),
                ('share/glib-2.0/schemas/', glob('*.gschema.xml')),
               ],
    )

