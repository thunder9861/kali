/*******************************************************************************
 * Copyright (c) 2005, 2012 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *     Hannes Erven <hannes@erven.at> - Bug 293841 - [FieldAssist] NumLock keyDown event should not close the proposal popup [with patch]
 *     Syntevo GmbH    - major refactoring
 *******************************************************************************/
package com.syntevo.q.swt;

import java.util.*;
import java.util.List;

import org.eclipse.jface.bindings.keys.*;
import org.eclipse.swt.*;
import org.eclipse.swt.events.*;
import org.eclipse.swt.graphics.*;
import org.eclipse.swt.layout.*;
import org.eclipse.swt.widgets.*;

/**
 * Refactored org.eclipse.jface.fieldassist.ContentProposalAdapter
 */
public abstract class QContentProposalAdapter {

	// Abstract ===============================================================

	protected abstract void proposalAccepted(QContentProposal proposal);

	protected abstract boolean supportsAutoActivation();

	protected abstract boolean isAutoActivateChar(char chr);

	// Fields =================================================================

	private final QContentProposalProvider proposalProvider;
	private final Control control;
	private final KeyStroke triggerKeyStroke;
	private final QControlContentAdapter controlContentAdapter;

	private ContentProposalPopup popup;

	private boolean watchModify;

	// Setup ==================================================================

	protected QContentProposalAdapter(QControlContentAdapter controlContentAdapter,
	                                  QContentProposalProvider proposalProvider,
	                                  KeyStroke triggerKeyStroke) {
		this.controlContentAdapter = controlContentAdapter;
		this.proposalProvider = proposalProvider;
		this.triggerKeyStroke = triggerKeyStroke;

		control = controlContentAdapter.getControl();

		final Listener controlListener = new ControlListener();
		control.addListener(SWT.KeyDown, controlListener);
		control.addListener(SWT.Traverse, controlListener);
		control.addListener(SWT.Modify, controlListener);
	}

	// Accessing ==============================================================

	protected void openProposalPopup() {
		openProposalPopup(false);
	}

	// Utils ==================================================================

	private void closeProposalPopup() {
		if (popup != null) {
			popup.close();
		}
	}

	private void openProposalPopup(boolean autoActivated) {
		if (control.isDisposed()) {
			return;
		}
		if (popup != null) {
			return;
		}

		final List<? extends QContentProposal> proposals = getProposals();
		if (proposals.size() > 0) {
			popup = new ContentProposalPopup(proposals);
			popup.open();
			popup.getShell().addDisposeListener(new DisposeListener() {
				@Override
				public void widgetDisposed(DisposeEvent event) {
					popup = null;
				}
			});
		}
		else if (!autoActivated) {
			control.getDisplay().beep();
		}
	}

	private List<? extends QContentProposal> getProposals() {
		if (control.isDisposed()) {
			return Collections.emptyList();
		}

		final int position = controlContentAdapter.getCaretPosition();
		final String contents = controlContentAdapter.getText();
		return proposalProvider.getProposals(contents, position);
	}

	private void autoActivate() {
		control.getDisplay().asyncExec(new Runnable() {
			@Override
			public void run() {
				if (control.isDisposed()) {
					return;
				}
				openProposalPopup(true);
			}
		});
	}

	private boolean isControlContentEmpty() {
		return controlContentAdapter.getText().length() == 0;
	}

	private boolean shouldPopupRemainOpen() {
		// If we always autoactivate or never autoactivate, it should remain open
		if (!supportsAutoActivation()) {
			return true;
		}

		final String content = controlContentAdapter.getText();
		for (int i = 0; i < content.length(); i++) {
			if (isAutoActivateChar(content.charAt(i))) {
				return true;
			}
		}
		return false;
	}

	private boolean allowsAutoActivate() {
		if (supportsAutoActivation()) {
			return true;
		}

		return triggerKeyStroke == null;
	}

	// Inner Classes ==========================================================

	/*
	 * The lightweight popup used to show content proposals for a text field. If
	 * additional information exists for a proposal, then selecting that
	 * proposal will result in the information being displayed in a secondary
	 * popup.
	 */
	private final class ContentProposalPopup extends QPopupDialog {
		/*
		 * The listener we install on the popup and related controls to
		 * determine when to close the popup. Some events (move, resize, close,
		 * deactivate) trigger closure as soon as they are received, simply
		 * because one of the registered listeners received them. Other events
		 * depend on additional circumstances.
		 */
		private final class PopupCloserListener implements Listener {
			private boolean scrollbarClicked;

			@Override
			public void handleEvent(final Event e) {
				// If focus is leaving an important widget or the field's
				// shell is deactivating
				if (e.type == SWT.FocusOut || e.type == SWT.Deactivate) {
					scrollbarClicked = false;
					/*
					 * Ignore this event if it's only happening because focus is
					 * moving between the popup shells, their controls, or a
					 * scrollbar. Do this in an async since the focus is not
					 * actually switched when this event is received.
					 */
					e.display.asyncExec(new Runnable() {
						@Override
						public void run() {
							if (isValid()) {
								if (scrollbarClicked || hasFocus()) {
									return;
								}
								// Workaround a problem on X and Mac, whereby at
								// this point, the focus control is not known.
								// This can happen, for example, when resizing
								// the popup shell on the Mac.
								// Check the active shell.
								final Shell activeShell = e.display.getActiveShell();
								if (activeShell == getShell()) {
									return;
								}
								close();
							}
						}
					});
					return;
				}

				// Scroll bar has been clicked. Remember this for focus event
				// processing.
				if (e.type == SWT.Selection) {
					scrollbarClicked = true;
					return;
				}
				// For all other events, merely getting them dictates closure.
				close();
			}

			// Install the listeners for events that need to be monitored for
			// popup closure.
			void installListeners() {
				// Listeners on this popup's table and scroll bar
				proposalTable.addListener(SWT.FocusOut, this);
				final ScrollBar scrollbar = proposalTable.getVerticalBar();
				if (scrollbar != null) {
					scrollbar.addListener(SWT.Selection, this);
				}

				// Listeners on this popup's shell
				getShell().addListener(SWT.Deactivate, this);
				getShell().addListener(SWT.Close, this);

				// Listeners on the target control
				control.addListener(SWT.MouseDoubleClick, this);
				control.addListener(SWT.MouseDown, this);
				control.addListener(SWT.Dispose, this);
				control.addListener(SWT.FocusOut, this);
				// Listeners on the target control's shell
				final Shell controlShell = control.getShell();
				controlShell.addListener(SWT.Move, this);
				controlShell.addListener(SWT.Resize, this);
				controlShell.addListener(SWT.Deactivate, this);
			}

			// Remove installed listeners
			void removeListeners() {
				if (isValid()) {
					proposalTable.removeListener(SWT.FocusOut, this);
					final ScrollBar scrollbar = proposalTable.getVerticalBar();
					if (scrollbar != null) {
						scrollbar.removeListener(SWT.Selection, this);
					}

					getShell().removeListener(SWT.Deactivate, this);
					getShell().removeListener(SWT.Close, this);
				}

				if (control != null && !control.isDisposed()) {
					control.removeListener(SWT.MouseDoubleClick, this);
					control.removeListener(SWT.MouseDown, this);
					control.removeListener(SWT.Dispose, this);
					control.removeListener(SWT.FocusOut, this);

					final Shell controlShell = control.getShell();
					controlShell.removeListener(SWT.Move, this);
					controlShell.removeListener(SWT.Resize, this);
					controlShell.removeListener(SWT.Deactivate, this);
				}
			}
		}

		/*
		 * The listener we will install on the target control.
		 */
		private final class TargetControlListener implements Listener {
			// Key events from the control
			@Override
			public void handleEvent(Event e) {
				if (!isValid()) {
					return;
				}

				final char key = e.character;

				// Traverse events are handled depending on whether the
				// event has a character.
				if (e.type == SWT.Traverse) {
					// let TAB work as normally
					if (key == SWT.TAB) {
						return;
					}

					// If the traverse event contains a legitimate character,
					// then we must set doit false so that the widget will
					// receive the key event. We return immediately so that
					// the character is handled only in the key event.
					// See https://bugs.eclipse.org/bugs/show_bug.cgi?id=132101
					if (key != 0) {
						e.doit = false;
						return;
					}
					// Traversal does not contain a character. Set doit true
					// to indicate TRAVERSE_NONE will occur and that no key
					// event will be triggered. We will check for navigation
					// keys below.
					e.detail = SWT.TRAVERSE_NONE;
					e.doit = true;
				}
				else {
					// Default is to only propagate when configured that way.
					// Some keys will always set doit to false anyway.
					e.doit = true;
				}

				// No character. Check for navigation keys.

				if (key == 0) {
					int newSelection = proposalTable.getSelectionIndex();
					final int visibleRows = (proposalTable.getSize().y / proposalTable.getItemHeight()) - 1;
					switch (e.keyCode) {
					case SWT.ARROW_UP:
						newSelection -= 1;
						if (newSelection < 0) {
							newSelection = proposalTable.getItemCount() - 1;
						}
						// Not typical - usually we get this as a Traverse and
						// therefore it never propagates. Added for consistency.
						if (e.type == SWT.KeyDown) {
							// don't propagate to control
							e.doit = false;
						}

						break;

					case SWT.ARROW_DOWN:
						newSelection += 1;
						if (newSelection > proposalTable.getItemCount() - 1) {
							newSelection = 0;
						}
						// Not typical - usually we get this as a Traverse and
						// therefore it never propagates. Added for consistency.
						if (e.type == SWT.KeyDown) {
							// don't propagate to control
							e.doit = false;
						}

						break;

					case SWT.PAGE_DOWN:
						newSelection += visibleRows;
						if (newSelection >= proposalTable.getItemCount()) {
							newSelection = proposalTable.getItemCount() - 1;
						}
						if (e.type == SWT.KeyDown) {
							// don't propagate to control
							e.doit = false;
						}
						break;

					case SWT.PAGE_UP:
						newSelection -= visibleRows;
						if (newSelection < 0) {
							newSelection = 0;
						}
						if (e.type == SWT.KeyDown) {
							// don't propagate to control
							e.doit = false;
						}
						break;

					case SWT.HOME:
						newSelection = 0;
						if (e.type == SWT.KeyDown) {
							// don't propagate to control
							e.doit = false;
						}
						break;

					case SWT.END:
						newSelection = proposalTable.getItemCount() - 1;
						if (e.type == SWT.KeyDown) {
							// don't propagate to control
							e.doit = false;
						}
						break;

					// If received as a Traverse, these should propagate
					// to the control as keydown. If received as a keydown,
					// proposals should be recomputed since the cursor
					// position has changed.
					case SWT.ARROW_LEFT:
					case SWT.ARROW_RIGHT:
						if (e.type == SWT.Traverse) {
							e.doit = false;
						}
						else {
							e.doit = true;
							final String contents = controlContentAdapter.getText();
							// If there are no contents, changes in cursor
							// position have no effect. Note also that we do 
							// not affect the filter text on ARROW_LEFT as 
							// we would with BS.
							if (contents.length() > 0) {
								asyncRecomputeProposals();
							}
						}
						break;

					// Any unknown keycodes will cause the popup to close.
					// Modifier keys are explicitly checked and ignored because
					// they are not complete yet (no character).
					default:
						if (e.keyCode != SWT.CAPS_LOCK && e.keyCode != SWT.NUM_LOCK
								&& e.keyCode != SWT.MOD1
								&& e.keyCode != SWT.MOD2
								&& e.keyCode != SWT.MOD3
								&& e.keyCode != SWT.MOD4) {
							close();
						}
						return;
					}

					// If any of these navigation events caused a new selection,
					// then handle that now and return.
					if (newSelection >= 0) {
						selectProposal(newSelection);
					}
					return;
				}

				// key != 0
				// Check for special keys involved in cancelling, accepting, or
				// filtering the proposals.
				switch (key) {
				case SWT.ESC:
					e.doit = false;
					close();
					break;

				case SWT.LF:
				case SWT.CR:
					e.doit = false;
					final Object p = getSelectedProposal();
					if (p != null) {
						acceptCurrentProposal();
					}
					else {
						close();
					}
					break;

				case SWT.BS:
					// There is no filtering provided by us, but some
					// clients provide their own filtering based on content.
					// Recompute the proposals if the cursor position
					// will change (is not at 0).
					final int pos = controlContentAdapter.getCaretPosition();
					// We rely on the fact that the contents and pos do not yet
					// reflect the result of the BS. If the contents were
					// already empty, then BS should not cause
					// a recompute.
					if (pos > 0) {
						asyncRecomputeProposals();
					}
					break;

				default:
					// If the key is a defined unicode character, and not one of
					// the special cases processed above, update the filter text
					// and filter the proposals.
					if (Character.isDefined(key)) {
						// Recompute proposals after processing this event.
						asyncRecomputeProposals();
					}
					break;
				}
			}
		}

		/*
		 * The listener installed on the target control.
		 */
		private Listener targetControlListener;

		/*
		 * The listener installed in order to close the popup.
		 */
		private PopupCloserListener popupCloser;

		/*
		 * The table used to show the list of proposals.
		 */
		private Table proposalTable;

		/*
		 * The proposals to be shown (cached to avoid repeated requests).
		 */
		private List<? extends QContentProposal> proposals;

		/**
		 * Constructs a new instance of this popup, specifying the control for
		 * which this popup is showing content, and how the proposals should be
		 * obtained and displayed.
		 */
		public ContentProposalPopup(List<? extends QContentProposal> proposals) {
			// IMPORTANT: Use of SWT.ON_TOP is critical here for ensuring
			// that the target control retains focus on Mac and Linux. Without
			// it, the focus will disappear, keystrokes will not go to the
			// popup, and the popup closer will wrongly close the popup.
			// On platforms where SWT.ON_TOP overrides SWT.RESIZE, we will live
			// with this.
			// See https://bugs.eclipse.org/bugs/show_bug.cgi?id=126138
			super(control.getShell(), SWT.NO_FOCUS | SWT.ON_TOP, false, false, false,
			      false, false, null, null);
			this.proposals = proposals;
		}

		@Override
		protected Control createDialogArea(Composite parent) {
			proposalTable = new Table(parent, SWT.H_SCROLL | SWT.V_SCROLL);

			// set the proposals to force population of the table.
			setProposals(proposals);

			proposalTable.setHeaderVisible(false);
			proposalTable.addSelectionListener(new SelectionAdapter() {
				// Default selection was made. Accept the current proposal.
				@Override
				public void widgetDefaultSelected(SelectionEvent e) {
					acceptCurrentProposal();
				}
			});
			return proposalTable;
		}

		@Override
		protected void adjustBounds() {
			// Get our control's location in display coordinates.
			final Point location = control.getDisplay().map(control.getParent(), null, control.getLocation());
			final Rectangle insertionBounds = controlContentAdapter.getInsertionBounds();
			final int initialX = location.x + 3 + insertionBounds.x;
			final int initialY = location.y + insertionBounds.y + insertionBounds.height;

			final GridData data = new GridData(GridData.FILL_BOTH);
			data.heightHint = Math.min(10, proposals.size()) * proposalTable.getItemHeight();
			data.widthHint = SWT.DEFAULT;
			proposalTable.setLayoutData(data);
			getShell().pack();
			final Point popupSize = getShell().getSize();

			// Constrain to the display
			final Rectangle constrainedBounds = getConstrainedShellBounds(new Rectangle(initialX, initialY, popupSize.x, popupSize.y));

			// If there has been an adjustment causing the popup to overlap
			// with the control, then put the popup above the control.
			if (constrainedBounds.y < initialY) {
				getShell().setLocation(initialX, location.y - popupSize.y);
			}
			else {
				getShell().setLocation(initialX, initialY);
			}
		}

		private void recomputeProposals() {
			final List<? extends QContentProposal> proposals = getProposals();
			if (proposals.isEmpty()) {
				this.proposals = proposals;
				close();
			}
			else {
				setProposals(proposals);
				adjustBounds();
			}
		}

		private void setProposals(List<? extends QContentProposal> proposals) {
			this.proposals = proposals;

			if (!isValid()) {
				return;
			}

			final int newSize = proposals.size();
			proposalTable.setRedraw(false);
			proposalTable.setItemCount(newSize);
			final TableItem[] items = proposalTable.getItems();
			for (int i = 0; i < items.length; i++) {
				final TableItem item = items[i];
				final QContentProposal proposal = proposals.get(i);
				item.setText(getString(proposal));
//				item.setData(proposal);
			}
			proposalTable.setRedraw(true);
			// Default to the first selection if there is content.
			if (proposals.size() > 0) {
				selectProposal(0);
			}
		}

		/*
		 * Get the string for the specified proposal. Always return a String of
		 * some kind.
		 */
		private String getString(QContentProposal proposal) {
			if (proposal == null) {
				return "";
			}
			return proposal.getLabel() == null ? proposal.getContent() : proposal.getLabel();
		}

		/*
		 * Answer true if the popup is valid, which means the table has been
		 * created and not disposed.
		 */
		private boolean isValid() {
			return proposalTable != null && !proposalTable.isDisposed();
		}

		/*
		 * Return whether the receiver has focus. Since 3.4, this includes a
		 * check for whether the info popup has focus.
		 */
		private boolean hasFocus() {
			if (!isValid()) {
				return false;
			}
			return getShell().isFocusControl() || proposalTable.isFocusControl();
		}

		/*
		 * Return the current selected proposal.
		 */
		private QContentProposal getSelectedProposal() {
			if (!isValid()) {
				return null;
			}

			final int i = proposalTable.getSelectionIndex();
			if (i < 0 || i >= proposals.size()) {
				return null;
			}
			return proposals.get(i);
		}

		/*
		 * Select the proposal at the given index.
		 */
		private void selectProposal(int index) {
			if (index < 0) {
				SWT.error(SWT.ERROR_INVALID_ARGUMENT);
			}

			if (!isValid() || index >= proposals.size()) {
				return;
			}
			proposalTable.setSelection(index);
			proposalTable.showSelection();
		}

		@Override
		public int open() {
			final int value = super.open();
			if (popupCloser == null) {
				popupCloser = new PopupCloserListener();
			}
			popupCloser.installListeners();
			return value;
		}

		@Override
		public boolean close() {
			popupCloser.removeListeners();
			return super.close();
		}

		/*
		 * Accept the current proposal.
		 */
		private void acceptCurrentProposal() {
			// Close before accepting the proposal. This is important
			// so that the cursor position can be properly restored at
			// acceptance, which does not work without focus on some controls.
			// See https://bugs.eclipse.org/bugs/show_bug.cgi?id=127108
			final QContentProposal proposal = getSelectedProposal();
			close();

			watchModify = false;

			if (proposal == null || control.isDisposed()) {
				return;
			}

			proposalAccepted(proposal);
		}

		/*
		 * In an async block, request the proposals. This is used when clients
		 * are in the middle of processing an event that affects the widget
		 * content. By using an async, we ensure that the widget content is up
		 * to date with the event.
		 */
		private void asyncRecomputeProposals() {
			if (isValid()) {
				control.getDisplay().asyncExec(new Runnable() {
					@Override
					public void run() {
						if (proposalTable.isDisposed()) {
							return;
						}

						recomputeProposals();
					}
				});
			}
			else {
				recomputeProposals();
			}
		}

		Listener getTargetControlListener() {
			if (targetControlListener == null) {
				targetControlListener = new TargetControlListener();
			}
			return targetControlListener;
		}
	}

	private class ControlListener implements Listener {
		@Override
		public void handleEvent(Event e) {
			switch (e.type) {
			case SWT.Traverse:
			case SWT.KeyDown:
				// If the popup is open, it gets first shot at the
				// keystroke and should set the doit flags appropriately.
				if (popup != null) {
					popup.getTargetControlListener().handleEvent(e);
					// See https://bugs.eclipse.org/bugs/show_bug.cgi?id=192633
					// If the popup is open and this is a valid character, we
					// want to watch for the modified text.
					if (e.character != 0) {
						watchModify = true;
					}

					return;
				}

				// We were only listening to traverse events for the popup
				if (e.type == SWT.Traverse) {
					return;
				}

				// The popup is not open. We are looking at keydown events
				// for a trigger to open the popup.
				if (triggerKeyStroke != null) {
					// Either there are no modifiers for the trigger and we
					// check the character field...
					if ((triggerKeyStroke.getModifierKeys() == KeyStroke.NO_KEY && triggerKeyStroke
							.getNaturalKey() == e.character)
							||
							// ...or there are modifiers, in which case the
							// keycode and state must match
							(triggerKeyStroke.getNaturalKey() == e.keyCode && ((triggerKeyStroke
									.getModifierKeys() & e.stateMask) == triggerKeyStroke
									.getModifierKeys()))) {
						// We never propagate the keystroke for an explicit
						// keystroke invocation of the popup
						e.doit = false;
						openProposalPopup(false);
						return;
					}
				}
				/*
				 * The triggering keystroke was not invoked. If a character
				 * was typed, compare it to the autoactivation characters.
				 */
				if (e.character != 0) {
					if (supportsAutoActivation()) {
						if (isAutoActivateChar(e.character)) {
							autoActivate();
						}
						else {
							// No autoactivation occurred, so record the key
							// down as a means to interrupt any
							// autoactivation that is pending due to
							// autoactivation delay.
							// watch the modify so we can close the popup in
							// cases where there is no longer a trigger
							// character in the content
							watchModify = true;
						}
					}
					else {
						// The autoactivate string is null. If the trigger
						// is also null, we want to act on any modification
						// to the content. Set a flag so we'll catch this
						// in the modify event.
						if (triggerKeyStroke == null) {
							watchModify = true;
						}
					}
				}
				else {
					// A non-character key has been pressed. Interrupt any
					// autoactivation that is pending due to autoactivation delay.
				}
				break;

			// There are times when we want to monitor content changes
			// rather than individual keystrokes to determine whether
			// the popup should be closed or opened based on the entire
			// content of the control.
			// The watchModify flag ensures that we don't autoactivate if
			// the content change was caused by something other than typing.
			// See https://bugs.eclipse.org/bugs/show_bug.cgi?id=183650
			case SWT.Modify:
				if (allowsAutoActivate() && watchModify) {
					watchModify = false;
					// We are in autoactivation mode, either for specific
					// characters or for all characters. In either case,
					// we should close the proposal popup when there is no
					// content in the control.
					if (isControlContentEmpty()) {
						// see https://bugs.eclipse.org/bugs/show_bug.cgi?id=192633
						closeProposalPopup();
					}
					else {
						// See https://bugs.eclipse.org/bugs/show_bug.cgi?id=147377
						// Given that we will close the popup when there are
						// no valid proposals, we must consider reopening it on any
						// content change when there are no particular autoActivation
						// characters
						if (supportsAutoActivation()) {
							// Autoactivation characters are defined, but this
							// modify event does not involve one of them.  See
							// if any of the autoactivation characters are left
							// in the content and close the popup if none remain.
							if (!shouldPopupRemainOpen()) {
								closeProposalPopup();
							}
						}
						else {
							autoActivate();
						}
					}
				}
				break;
			default:
				break;
			}
		}
	}
}
