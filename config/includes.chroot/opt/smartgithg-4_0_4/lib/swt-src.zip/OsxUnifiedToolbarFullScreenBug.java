import org.eclipse.swt.*;
import org.eclipse.swt.layout.*;
import org.eclipse.swt.widgets.*;

/**
 * @author Thomas Singer
 * https://bugs.eclipse.org/bugs/show_bug.cgi?id=392803
 */
public class OsxUnifiedToolbarFullScreenBug {

	public static void main(String[] args) {
		final Display display = new Display();
		final Shell shell = new Shell(display, SWT.SHELL_TRIM);
		shell.setText("Title");
		shell.setLayout(new FillLayout());

		new Text(shell, SWT.MULTI).setText("hello world");

		final ToolBar toolBar = shell.getToolBar();
		final ToolItem toolItem = new ToolItem(toolBar, SWT.PUSH);
		toolItem.setText("Hello");
		toolItem.setImage(display.getSystemImage(SWT.ICON_QUESTION));

		final Menu menuBar = new Menu(shell, SWT.BAR);
		shell.setMenuBar(menuBar);

		final Menu viewMenu = new Menu(menuBar);
		final MenuItem viewMenuItem = new MenuItem(menuBar, SWT.CASCADE);
		viewMenuItem.setText("View");
		viewMenuItem.setMenu(viewMenu);

		final MenuItem showToolBarMenuItem = new MenuItem(viewMenu, SWT.CHECK);
		showToolBarMenuItem.setText("Show Toolbar");
		showToolBarMenuItem.setSelection(true);
		showToolBarMenuItem.addListener(SWT.Selection, new Listener() {
			@Override
			public void handleEvent(Event event) {
				toolBar.setVisible(showToolBarMenuItem.getSelection());
			}
		});

		shell.setSize(300, 200);
		shell.open();

		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		display.dispose();
	}
}
