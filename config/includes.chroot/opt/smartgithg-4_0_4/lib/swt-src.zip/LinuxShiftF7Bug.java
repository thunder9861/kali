import org.eclipse.swt.*;
import org.eclipse.swt.layout.*;
import org.eclipse.swt.widgets.*;

/**
 * @author Thomas Singer
 * https://bugs.eclipse.org/bugs/show_bug.cgi?id=393541
 */
public class LinuxShiftF7Bug {

	public static void main(String[] args) {
		final Display display = new Display();
		final Shell shell = new Shell(display, SWT.SHELL_TRIM);
		shell.setText("Title");
		shell.setLayout(new FillLayout());

		final Text text = new Text(shell, SWT.MULTI);

		final Menu menuBar = new Menu(shell, SWT.BAR);
		shell.setMenuBar(menuBar);

		final Menu fileMenu = new Menu(menuBar);
		final MenuItem fileMenuItem = new MenuItem(menuBar, SWT.CASCADE);
		fileMenuItem.setText("File");
		fileMenuItem.setMenu(fileMenu);

		final Listener listener = new Listener() {
			@Override
			public void handleEvent(Event event) {
				final MenuItem menuItem = (MenuItem)event.widget;
				text.append(menuItem.getText() + "\n");
			}
		};
		createMenuItem(fileMenu, "Foo", SWT.F7).addListener(SWT.Selection, listener);
		createMenuItem(fileMenu, "Bar", SWT.SHIFT | SWT.F7).addListener(SWT.Selection, listener);

		shell.setSize(300, 200);
		shell.open();

		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		display.dispose();
	}

	private static MenuItem createMenuItem(Menu viewMenu, String text, int accelerator) {
		final MenuItem menuItem = new MenuItem(viewMenu, SWT.PUSH);
		menuItem.setText(text);
		menuItem.setAccelerator(accelerator);
		return menuItem;
	}
}
